package demo_example;

public class SeatingArrangementConfigurationException extends RuntimeException {
	public SeatingArrangementConfigurationException(String message) {
		super(message);
	}

}
