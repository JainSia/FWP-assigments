package demo_example;

import java.sql.Time;
import java.util.Map;

public class Show {

	private int id;
	private String movieTitle;
	private Map<Time, String> showTiming;


	public Show(int id, String movieTitle, Map<Time, String> showTiming) {
		super();
		this.id = id;
		this.movieTitle = movieTitle;
		this.showTiming = showTiming;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public Map<Time, String> getShowTiming() {
		return showTiming;
	}
	public void setShowTiming(Map<Time, String> showTiming) {
		this.showTiming = showTiming;
	}
	@Override
	public String toString() {
		return "Show [id=" + id + ", movieTitle=" + movieTitle + ", ShowTiming=" + showTiming + "]";
	}

	
	
}
