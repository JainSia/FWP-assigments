package demo_example;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.google.gson.Gson;

public class PyramidTest {
	static List<Integer> noOfSeatsInRows = new ArrayList<>();
	static Map<String, Integer> seatingArranagement=new HashMap<>();
	public static void main(String[] args) throws IOException {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int noOfRows = 0;
		int noOfSeats = 0;
		

		int category;
		// int rowCount=0;

		System.out.println("Select Category-->");
		System.out.println("1.Premium");
		System.out.println("2.Gold");
		System.out.println("3.Silver");
		category = sc.nextInt();
		switch (category) {
		case 1:
			System.out.println("Enter no of rows");
			noOfRows = sc.nextInt();
			System.out.println("Enter no of seats");
			noOfSeats = sc.nextInt();
			if (noOfRows > 5 || noOfSeats > 30) {
				throw new SeatingArrangementConfigurationException(
						"Rows cannot be more than 5 and seats per row cannot be more than 30");
			}
			Map<String,Integer> pyramid = makePyramid(noOfRows, noOfSeats);
			Gson gson=new Gson();
			String py=gson.toJson(pyramid);
			String filpath = "src/seating.json";
			File file = new File(filpath);
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file.getAbsolutePath(), true));
			
				bufferedWriter.write(py);
				bufferedWriter.newLine();
		
			
			System.out.println("wrote in file");
			
			
//			BufferedReader bufferedReader=new BufferedReader(new FileReader(file));
//			String content=bufferedReader.readLine();
//			while(content!=null){
//				System.out.println(content);
//				bufferedReader.readLine();
//			}
			bufferedWriter.close();
			Set<Entry<String, Integer>> entrySet= seatingArranagement.entrySet();
			for (Entry<String,Integer> entry : entrySet) {
				System.out.println(entry.getKey()+entry.getValue());
			}

		case 2:
			System.out.println("Enter no of rows");
			noOfRows = sc.nextInt();
			System.out.println("Enter no of seats");
			noOfSeats = sc.nextInt();
			if (noOfRows > 5 || noOfSeats > 30) {
				throw new SeatingArrangementConfigurationException(
						"Rows cannot be more than 5 and seats per row cannot be more than 30");
			}
			makePyramid(noOfRows, noOfSeats);
		case 3:
			System.out.println("Enter no of rows");
			noOfRows = sc.nextInt();
			System.out.println("Enter no of seats");
			noOfSeats = sc.nextInt();
			if (noOfRows > 5 || noOfSeats > 30) {
				throw new SeatingArrangementConfigurationException(
						"Rows cannot be more than 5 and seats per row cannot be more than 30");
			}
		case 4:
			System.exit(0);

		}
	}

	@SuppressWarnings("null")
	private static Map<String, Integer> makePyramid(int noOfRows, int noOfSeats) {
		
		for (int i = 0; i < noOfRows; i++) {
			noOfSeatsInRows.add(noOfSeats);
			String rowName="G" + (i + 1);
			seatingArranagement.put(rowName, noOfSeats);
			System.out.print(rowName + "  ");

			for (int j = 1; j <= i * 2; j++) {
				System.out.print(" ");
			}

			for (int j = 1; j <= noOfSeats; j++) {
				System.out.print(j + " ");
			}

			System.out.println();
			noOfSeats -= 2;
			
		}
		return seatingArranagement;
	}

}
