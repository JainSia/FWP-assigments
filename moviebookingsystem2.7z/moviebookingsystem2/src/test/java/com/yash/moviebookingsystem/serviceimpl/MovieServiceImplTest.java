package com.yash.moviebookingsystem.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.moviebookingsystem.dao.MovieDAO;
import com.yash.moviebookingsystem.domain.Movie;
import com.yash.moviebookingsystem.exception.EmptyFieldException;
import com.yash.moviebookingsystem.service.MovieService;

public class MovieServiceImplTest {

	@Mock
	private MovieDAO movieDAO;
	
	private MovieService movieService;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test(expected=NullPointerException.class)
	public void addMovie_MovieNullObjectGiven_throwNullPointerException() throws EmptyFieldException {
		
		Movie movie=null;
		String screenName="audi-1";
		movieService=new MovieServiceImpl(movieDAO);
		movieService.add(movie,screenName);
	}
	
	@Test(expected=EmptyFieldException.class)
	public void addMovie_EmptyMovieFieldsGiven_throwEmptyFieldException() throws EmptyFieldException {
		
		String screenName="audi-1";
		List<String> actors=new ArrayList<>();
		actors.add("aliabhatt");
		Movie movie=new Movie(1,"Raazi","2:00:00","",actors);
		movieService=new MovieServiceImpl(movieDAO);
		movieService.add(movie,screenName);
	}
	
	@Test(expected=EmptyFieldException.class)
	public void addMovie_EmptyScreenNameGiven_throwEmptyFieldException() throws EmptyFieldException {
		
		String screenName="";
		List<String> actors=new ArrayList<>();
		actors.add("aliabhatt");
		Movie movie=new Movie(1,"Raazi","2:00:00","",actors);
		movieService=new MovieServiceImpl(movieDAO);
		movieService.add(movie,screenName);
	}
	
	@Test(expected=EmptyFieldException.class)
	public void addMovie_DuplicateMovieNameGiven_throwEmptyFieldException() throws EmptyFieldException {
		
		String screenName="";
		List<String> actors=new ArrayList<>();
		actors.add("aliabhatt");
		Movie movie=new Movie(1,"Raazi","2:00:00","",actors);
		movieService=new MovieServiceImpl(movieDAO);
		movieService.add(movie,screenName);
	}
	
	@Test
	public void addMovie_MovieObjectGiven_shouldReturnOne() throws EmptyFieldException {
		String screenName="audi-1";
		List<String> actors=new ArrayList<>();
		actors.add("aliabhatt");
		Movie movie=new Movie(1,"Razzi","2:00:00","SRK",actors);
		when(movieDAO.insert(movie,screenName)).thenReturn(1);
		movieService=new MovieServiceImpl(movieDAO);
		int rowAffected=movieService.add(movie,screenName);
		assertEquals(1, rowAffected);
	}

}
