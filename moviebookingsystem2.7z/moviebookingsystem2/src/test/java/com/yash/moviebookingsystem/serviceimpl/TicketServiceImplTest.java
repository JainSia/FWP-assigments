package com.yash.moviebookingsystem.serviceimpl;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.moviebookingsystem.dao.TicketDAO;
import com.yash.moviebookingsystem.domain.Ticket;
import com.yash.moviebookingsystem.enumeration.Category;
import com.yash.moviebookingsystem.service.TicketService;

public class TicketServiceImplTest {

	@Mock
	private TicketDAO ticketDAO;
	
	private TicketService ticketService;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void bookTicket_ticketObjectGiven_shouldReturnOne() {
		when(ticketDAO.bookTicket(any(Ticket.class))).thenReturn(1);
		Ticket ticket=new Ticket(1,Category.Premium,"Razzi",200.00,200);
		ticketService=new TicketServiceImpl(ticketDAO);
		ticketService.bookTicket(ticket);
	}

	
	
}
