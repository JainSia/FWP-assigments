package com.yash.moviebookingsystem.service;

import com.yash.moviebookingsystem.domain.Ticket;

public interface TicketService {

	public int bookTicket(Ticket ticket);

}
