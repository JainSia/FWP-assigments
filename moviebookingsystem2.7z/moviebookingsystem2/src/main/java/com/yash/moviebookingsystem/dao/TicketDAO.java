package com.yash.moviebookingsystem.dao;

import com.yash.moviebookingsystem.domain.Ticket;

public interface TicketDAO {

	public int bookTicket(Ticket ticket);

}
