package com.yash.moviebookingsystem.exception;

@SuppressWarnings("serial")
public class MovieAlreadyExistException extends Exception{

	public MovieAlreadyExistException(String message) {
		super(message);
	}
}
