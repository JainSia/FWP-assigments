package com.yash.moviebookingsystem.enumeration;

public enum Category {

	Silver,Gold,Premium
}
