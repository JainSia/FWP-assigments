package com.yash.moviebookingsystem.domain;

import com.yash.moviebookingsystem.enumeration.Category;

public class Row {

	private long id;
	private Seat seat;
	private Category category;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Seat getSeat() {
		return seat;
	}
	public void setSeat(Seat seat) {
		this.seat = seat;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	
}
