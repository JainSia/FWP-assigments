package com.yash.moviebookingsystem.main;

import com.yash.moviebookingsystem.util.MBSMenu;

public class StartUp {

	public static void main(String[] args) {
		MBSMenu mbsMenu=new MBSMenu();
		mbsMenu.getMenu();
	}
}
