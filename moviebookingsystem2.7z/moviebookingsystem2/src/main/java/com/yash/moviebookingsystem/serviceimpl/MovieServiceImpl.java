package com.yash.moviebookingsystem.serviceimpl;

import com.yash.moviebookingsystem.dao.MovieDAO;
import com.yash.moviebookingsystem.domain.Movie;
import com.yash.moviebookingsystem.exception.EmptyFieldException;
import com.yash.moviebookingsystem.service.MovieService;

public class MovieServiceImpl implements MovieService {

	private MovieDAO movieDAO;
	public MovieServiceImpl(MovieDAO movieDAO) {
		this.movieDAO=movieDAO;
	}
	@Override
	public int add(Movie movie,String screenName) throws EmptyFieldException {
		if(movie==null){
			throw new NullPointerException("Movie cannot be null");
		}
		if(movie.getId()<0|| movie.getMovieName()==""|| movie.getDuration()==""|| movie.getProduction()=="" || screenName=="") {
			throw new EmptyFieldException("Movie fields cannot be empty");
		}
		return movieDAO.insert(movie,screenName);
	}

}
