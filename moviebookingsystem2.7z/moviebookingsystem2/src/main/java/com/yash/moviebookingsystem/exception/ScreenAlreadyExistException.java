package com.yash.moviebookingsystem.exception;

@SuppressWarnings("serial")
public class ScreenAlreadyExistException extends Exception{

	public ScreenAlreadyExistException(String message) {
		super(message);
	}
}
