package com.yash.moviebookingsystem.domain;

import java.util.List;

public class Movie {

	private long id;
	private String movieName;
	private String duration;
	private String production;
	private List<String> actors;
	
	public Movie(long id, String movieName, String duration, String production, List<String> actors) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.duration = duration;
		this.production = production;
		this.actors = actors;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getProduction() {
		return production;
	}
	public void setProduction(String production) {
		this.production = production;
	}
	public List<String> getActors() {
		return actors;
	}
	
	public void setActors(List<String> actors) {
		this.actors = actors;
	}
	
	
}
