package com.yash.moviebookingsystem.serviceimpl;

import com.yash.moviebookingsystem.dao.TicketDAO;
import com.yash.moviebookingsystem.domain.Ticket;
import com.yash.moviebookingsystem.service.TicketService;

public class TicketServiceImpl implements TicketService {

	private TicketDAO ticketDAO;
	public TicketServiceImpl(TicketDAO ticketDAO) {
		this.ticketDAO=ticketDAO;
	}

	@Override
	public int bookTicket(Ticket ticket) {
		return ticketDAO.bookTicket(ticket);
	}

}
